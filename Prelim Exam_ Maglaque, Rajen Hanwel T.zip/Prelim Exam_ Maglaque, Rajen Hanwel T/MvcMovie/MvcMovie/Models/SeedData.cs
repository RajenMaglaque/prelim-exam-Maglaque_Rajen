﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.DependencyInjection;
using MvcMovie.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMovie.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using var context = new MvcMovieContext(serviceProvider.GetRequiredService<DbContextOptions<MvcMovieContext>>());
            {
                if (context.Movies.Any())
                
                    {
                    return;
                }
                    context.Movies.AddRange(
                    new Movie
                    {
                        Title = "Avengers: Age of Ultron",
                        ReleaseDate = DateTime.Parse("2015-5-1"),
                        Genre = "Action, Sci-Fi",
                        Price = 7.99M,
                    },
                    new Movie
                    {
                        Title = "Black Phanther",
                        ReleaseDate = DateTime.Parse("2018-2-16"),
                        Genre = "Action, Sci-Fi, Drama",
                        Price = 8.99M,
                    },
                    new Movie
                    {
                        Title = "The Grudge",
                        ReleaseDate = DateTime.Parse("2020-1-5"),
                        Genre = "Horror",
                        Price = 6.99M,
                    });
                    context.SaveChanges();
                
            }
        }

    }
}
